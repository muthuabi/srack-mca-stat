document.addEventListener('DOMContentLoaded', function() {
    const usersContainer = document.getElementById('usersContainer');
    const loadAllBtn = document.getElementById('loadAllBtn');
    const loadingIndicator = document.getElementById('loadingIndicator');
    const searchInput = document.getElementById('searchInput');
    const searchBtn = document.getElementById('searchBtn');
    
    // Load all users initially
    fetchUsers();
    
    // Load all SkillRack data
    loadAllBtn.addEventListener('click', function() {
        fetchAllSkillRackData();
    });
    
    // Search functionality
    searchBtn.addEventListener('click', function() {
        const searchTerm = searchInput.value.toLowerCase();
        if (!searchTerm) {
            fetchUsers();
            return;
        }
        
        fetch('/api/users')
            .then(response => response.json())
            .then(users => {
                const filteredUsers = users.filter(user => 
                    user.registerNumber.toLowerCase().includes(searchTerm) || 
                    user.email.toLowerCase().includes(searchTerm)
                );
                displayUsers(filteredUsers);
            });
    });
    
    function fetchUsers() {
        fetch('/api/users')
            .then(response => response.json())
            .then(users => {
                displayUsers(users);
            });
    }
    
    function fetchAllSkillRackData() {
        loadingIndicator.style.display = 'block';
        usersContainer.innerHTML = '';
        
        fetch('/api/all-users-data')
            .then(response => response.json())
            .then(data => {
                loadingIndicator.style.display = 'none';
                displayUsersWithSkillRackData(data);
            })
            .catch(error => {
                loadingIndicator.style.display = 'none';
                console.error('Error:', error);
            });
    }
    
    function displayUsers(users) {
        usersContainer.innerHTML = '';
        
        users.forEach(user => {
            const userCard = document.createElement('div');
            userCard.className = 'col-md-4';
            userCard.innerHTML = `
                <div class="user-card">
                    <h5>${user.registerNumber}</h5>
                    <p>Email: ${user.email}</p>
                    <a href="${user.skillRackURL}" target="_blank">SkillRack Profile</a>
                    <button class="btn btn-sm btn-info mt-2 load-skillrack-btn" data-reg="${user.registerNumber}">
                        Load SkillRack Data
                    </button>
                    <div class="skillrack-data" id="data-${user.registerNumber}" style="display: none;"></div>
                </div>
            `;
            usersContainer.appendChild(userCard);
        });
        
        // Add event listeners to the load buttons
        document.querySelectorAll('.load-skillrack-btn').forEach(button => {
            button.addEventListener('click', function() {
                const regNo = this.getAttribute('data-reg');
                fetchSkillRackData(regNo);
            });
        });
    }
    
    function displayUsersWithSkillRackData(usersData) {
        usersContainer.innerHTML = '';
        
        usersData.forEach(item => {
            const user = item.user;
            const skillRackData = item.skillRackData;
            
            const userCard = document.createElement('div');
            userCard.className = 'col-md-6';
            
            if (!skillRackData) {
                userCard.innerHTML = `
                    <div class="user-card">
                        <h5>${user.registerNumber}</h5>
                        <p>Email: ${user.email}</p>
                        <a href="${user.skillRackURL}" target="_blank">SkillRack Profile</a>
                        <div class="alert alert-danger mt-2">Failed to load SkillRack data</div>
                    </div>
                `;
            } else {
                // Create language stats HTML dynamically
                let languagesHTML = '';
                for (const [lang, count] of Object.entries(skillRackData.languageStats)) {
                    languagesHTML += `<p><strong>${lang.toUpperCase()}:</strong> ${count}</p>`;
                }
                
                userCard.innerHTML = `
                    <div class="user-card">
                        <h4>${skillRackData.basicInfo.name}</h4>
                        <p><strong>Reg No:</strong> ${user.registerNumber}</p>
                        <p><strong>Program:</strong> ${skillRackData.basicInfo.program}</p>
                        <p><strong>College:</strong> ${skillRackData.basicInfo.college}</p>
                        <p><strong>Year:</strong> ${skillRackData.basicInfo.year}</p>
                        <p><strong>Gender:</strong> ${skillRackData.basicInfo.gender}</p>
                        <a href="${user.skillRackURL}" target="_blank">SkillRack Profile</a>
                        
                        <div class="stats-container">
                            <div class="stat-box">
                                <h5>Rank & Medals</h5>
                                <p><strong>Rank:</strong> ${skillRackData.programmingSummary.rank}</p>
                                <p><strong>Level:</strong> ${skillRackData.programmingSummary.level}</p>
                                <p><strong>Gold:</strong> ${skillRackData.programmingSummary.medals.gold}</p>
                                <p><strong>Silver:</strong> ${skillRackData.programmingSummary.medals.silver}</p>
                                <p><strong>Bronze:</strong> ${skillRackData.programmingSummary.medals.bronze}</p>
                            </div>
                            
                            <div class="stat-box">
                                <h5>Program Counts</h5>
                                <p><strong>Solved:</strong> ${skillRackData.programCounts.programsSolved}</p>
                                <p><strong>Code Test:</strong> ${skillRackData.programCounts.codeTest}</p>
                                <p><strong>Code Track:</strong> ${skillRackData.programCounts.codeTrack}</p>
                                <p><strong>DC:</strong> ${skillRackData.programCounts.dc}</p>
                                <p><strong>DT:</strong> ${skillRackData.programCounts.dt}</p>
                                <p><strong>Code Tutor:</strong> ${skillRackData.programCounts.codeTutor}</p>
                            </div>
                            
                            <div class="stat-box">
                                <h5>Languages</h5>
                                ${languagesHTML}
                            </div>
                        </div>
                        
                        <div class="points-calculation">
                            <h5>Points Calculation</h5>
                            <p><strong>Code Tutor:</strong> ${skillRackData.pointsCalculation.codeTutor}</p>
                            <p><strong>Code Track:</strong> ${skillRackData.pointsCalculation.codeTrack}</p>
                            <p><strong>DC:</strong> ${skillRackData.pointsCalculation.dc}</p>
                            <p><strong>DT:</strong> ${skillRackData.pointsCalculation.dt}</p>
                            <p><strong>Code Test:</strong> ${skillRackData.pointsCalculation.codeTest}</p>
                            <p><strong>Total Points:</strong> ${skillRackData.pointsCalculation.totalPoints}</p>
                        </div>
                    </div>
                `;
            }
            
            usersContainer.appendChild(userCard);
        });
    }
    
    function fetchSkillRackData(registerNumber) {
        const dataContainer = document.getElementById(`data-${registerNumber}`);
        dataContainer.style.display = 'block';
        dataContainer.innerHTML = '<p>Loading data...</p>';
        
        fetch(`/api/user/${registerNumber}`)
            .then(response => response.json())
            .then(data => {
                if (data.skillRackData) {
                    const skillRackData = data.skillRackData;
                    dataContainer.innerHTML = `
                        <div class="mt-3">
                            <h5>${skillRackData.basicInfo.name}</h5>
                            <p><strong>Rank:</strong> ${skillRackData.programmingSummary.rank}</p>
                            <p><strong>Programs Solved:</strong> ${skillRackData.programCounts.programsSolved}</p>
                            <p><strong>Points:</strong> ${skillRackData.pointsCalculation.totalPoints}</p>
                        </div>
                    `;
                } else {
                    dataContainer.innerHTML = '<div class="alert alert-danger">Failed to load SkillRack data</div>';
                }
            })
            .catch(error => {
                dataContainer.innerHTML = '<div class="alert alert-danger">Error loading data</div>';
                console.error('Error:', error);
            });
    }
});