const express = require('express');
const axios = require('axios');
const { JSDOM } = require('jsdom');
const path = require('path');

const app = express();

// Serve static files from the public directory
app.use(express.static(path.join(__dirname, 'public')));

// Parse JSON bodies
app.use(express.json());

// Static user data
// const users = [
//   {
//     "registerNumber": "2403917762221001",
//     "skillRackURL": "http://www.skillrack.com/profile/512627/e01f848cd84e199f340a353045d4012ee5f7510c",
//     "email": "afraaz@student.tce.edu"
//   },

//   {
//     "registerNumber": "2403917762222028",
//     "skillRackURL": "http://www.skillrack.com/profile/512654/5b6e5e604c56a03e0e4d89ef621a7a58213ff728",
//     "email": "sowmyagracy@gmail.com"
//   }
// ];
const users= require("./data/data.json");
// Function to extract data from HTML (same as before)
async function extractSkillRackData(url) {
  try {
    const response = await axios.get(url);
    const html = response.data;
    const dom = new JSDOM(html);
    const document = dom.window.document;

    // Extract basic info
    const name = document.querySelector('.ui.big.label.black')?.textContent.trim() || 'N/A';
    const registerNumber = document.querySelector('.ui.twelve.wide.column')?.textContent.match(/\d{16}/)?.[0] || 'N/A';
    const program = document.querySelector('.ui.large.label')?.textContent.trim() || 'N/A';
    const college = document.querySelector('.ui.twelve.wide.column')?.textContent.includes('Thiagarajar College of Engineering (TCE), Madurai') ? 'Thiagarajar College of Engineering (TCE), Madurai' : 'N/A';
    const year = document.querySelector('.ui.twelve.wide.column')?.textContent.match(/\(.*?\)\s*(\d{4})/)?.[1] || 'N/A';
    const gender = document.querySelector('.ui.fourteen.wide.left.aligned.column')?.textContent.trim() || 'N/A';

    // Extract programming summary
    const rank = document.querySelector('.ui.five.small.statistics .statistic .value')?.textContent.replace(/\D/g, '') || '0';
    const level = document.querySelectorAll('.ui.five.small.statistics .statistic .value')[1]?.textContent || '0/10';
    const gold = document.querySelectorAll('.ui.five.small.statistics .statistic .value')[2]?.textContent.replace(/\D/g, '') || '0';
    const silver = document.querySelectorAll('.ui.five.small.statistics .statistic .value')[3]?.textContent.replace(/\D/g, '') || '0';
    const bronze = document.querySelectorAll('.ui.five.small.statistics .statistic .value')[4]?.textContent.replace(/\D/g, '') || '0';

    // Extract program counts
    const programsSolved = document.querySelectorAll('.ui.six.small.statistics .statistic .value')[0]?.textContent.replace(/\D/g, '') || '0';
    const codeTest = document.querySelectorAll('.ui.six.small.statistics .statistic .value')[1]?.textContent.replace(/\D/g, '') || '0';
    const codeTrack = document.querySelectorAll('.ui.six.small.statistics .statistic .value')[2]?.textContent.replace(/\D/g, '') || '0';
    const dc = document.querySelectorAll('.ui.six.small.statistics .statistic .value')[3]?.textContent.replace(/\D/g, '') || '0';
    const dt = document.querySelectorAll('.ui.six.small.statistics .statistic .value')[4]?.textContent.replace(/\D/g, '') || '0';
    const codeTutor = document.querySelectorAll('.ui.six.small.statistics .statistic .value')[5]?.textContent.replace(/\D/g, '') || '0';

    // Extract all language stats dynamically
    const languageStats = {};
    const languageElements = document.querySelectorAll('.ui.six.small.statistics .statistic');
    languageElements.forEach(el => {
        const label = el.querySelector('.label')?.textContent.trim();
        const value = el.querySelector('.value')?.textContent.replace(/\D/g, '') || '0';
        if (label && !['PROGRAMS SOLVED', 'CODE TEST', 'CODE TRACK', 'DC', 'DT', 'CODE TUTOR'].includes(label.toUpperCase())) {
            languageStats[label.toLowerCase()] = value;
        }
    });

    // Calculate points
    const codeTutorPoints = parseInt(codeTutor) * 0;
    const codeTrackPoints = parseInt(codeTrack) * 2;
    const dcPoints = parseInt(dc) * 2;
    const dtPoints = parseInt(dt) * 20;
    const codeTestPoints = parseInt(codeTest) * 30;
    const totalPoints = codeTutorPoints + codeTrackPoints + dcPoints + dtPoints + codeTestPoints;
    const percentage = (totalPoints / 5000 * 100).toFixed(2);

    return {
      basicInfo: {
        name,
        registerNumber,
        program,
        college,
        year,
        gender
      },
      programmingSummary: {
        rank,
        level,
        medals: {
          gold,
          silver,
          bronze
        }
      },
      programCounts: {
        programsSolved,
        codeTest,
        codeTrack,
        dc,
        dt,
        codeTutor
      },
      languageStats,
      pointsCalculation: {
        codeTutor: `${codeTutor} x 0 = ${codeTutorPoints}`,
        codeTrack: `${codeTrack} x 2 = ${codeTrackPoints}`,
        dc: `${dc} x 2 = ${dcPoints}`,
        dt: `${dt} x 20 = ${dtPoints}`,
        codeTest: `${codeTest} x 30 = ${codeTestPoints}`,
        totalPoints: `${totalPoints} (${percentage}%)`
      }
    };
  } catch (error) {
    console.error('Error extracting data:', error);
    return null;
  }
}

// API endpoints (same as before)
app.get('/api/users', (req, res) => {
  res.json(users);
});

app.get('/api/user/:registerNumber', async (req, res) => {
  const registerNumber = req.params.registerNumber;
  const user = users.find(u => u.registerNumber === registerNumber);
  
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }

  try {
    const skillRackData = await extractSkillRackData(user.skillRackURL);
    if (!skillRackData) {
      return res.status(500).json({ error: 'Failed to fetch SkillRack data' });
    }
    
    res.json({
      user,
      skillRackData
    });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.get('/api/all-users-data', async (req, res) => {
  try {
    const allUsersData = [];
    
    for (const user of users) {
      try {
        const skillRackData = await extractSkillRackData(user.skillRackURL);
        allUsersData.push({
          user,
          skillRackData
        });
      } catch (error) {
        console.error(`Error processing user ${user.registerNumber}:`, error);
        allUsersData.push({
          user,
          skillRackData: null,
          error: 'Failed to fetch SkillRack data'
        });
      }
    }
    
    res.json(allUsersData);
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Serve the main HTML file for all other routes
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});